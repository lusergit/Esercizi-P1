#include<iostream>
using namespace std;


void stampa(int*P,int m,int i)
{
  if(i==m)
    {cout<<endl; return;}
  cout<<'('<<i<<','<<P[i]<<')'<<' ';
  stampa(P,m,i+1);
}


   
main()
{
  int m;
  cin>>m;
  int*P=new int[m];
  bool*N =new bool[m*m];
  for(int i=0; i<m*m; i++)
          cin>>N[i];
  bool x=partenza(N,m,0,P);//da fare 
  cout<<"start"<<endl;
  if(x)
    { cout<<"esiste un cammino e quello più a sinistra è:"<<endl;
      stampa(P,m,0);
     
    }    
  else
    cout<<"il cammino non esiste"<<endl;
  cout<<"end"<<endl;
      
}

