#include<iostream>
using namespace std;
struct nodo{int info; nodo* next; nodo(int a=0, nodo* b=0){info=a; next=b;}};
struct nodoP{nodo* P; nodoP* next; nodoP(nodo* a=0, nodoP* b=0){P=a; next=b;}};



main()
{
  cout<<"start"<<endl;
  nodo*L=leggi();
  nodoP*y=F(L);
  stampa(y);
  cout<<endl;
  cout<<"end"<<endl;

}
