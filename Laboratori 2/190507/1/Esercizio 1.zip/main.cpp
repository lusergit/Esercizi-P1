#include<iostream>

struct nodo {
    char chiave;
    nodo *next;
    nodo(char c='\0', nodo* n=NULL);
};

struct coda {
    nodo *inizio;
    nodo *fine;
    coda();
};

void push(char c, coda &Q);
char pop(coda &Q);
bool e_vuota(coda Q);

// IMPLEMENTARE I METODI DELLA LIBRERIA `coda`

int main() 
{
    coda Q;
    
    cout << "start" << endl;
    // IMPLEMENTARE LA SOLUZIONE DELL'ESERCIZIO UTILIZZANDO LE FUNZIONI ESPOSTE DALLA LIBRERIA `coda`
    cout << "end" << endl;
}