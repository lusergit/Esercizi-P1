#include<iostream>
#include "BST.h"
using namespace std;
//contiene le implementazioni delle 7 funzioni richieste