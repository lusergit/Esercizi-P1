#include<iostream>
#include "BST.h"
using namespace std;
main()
{
    //prepara un albero iniziale non triviale
  nodo* r=new nodo(15, new nodo(7), new nodo(19));
  r->left->right=new nodo (9, new nodo(8));
  r->right->right=new nodo(25, new nodo(22));
  
  bool stop=false;
  while(!stop)
    {
      //legge le istruzoni e le esegue
    }
}
